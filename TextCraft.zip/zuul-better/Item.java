
/**
 * class Objects - geef hier een beschrijving van deze class
 *
 * @author (jouw naam)
 * @version (versie nummer of datum)
 */
public class Item
{
   private String itemDescription;
   
   public Item(String itemDescription){
       this.itemDescription = itemDescription;
    }
   public String getItemDescription(){
      return itemDescription;
    }
    
}
